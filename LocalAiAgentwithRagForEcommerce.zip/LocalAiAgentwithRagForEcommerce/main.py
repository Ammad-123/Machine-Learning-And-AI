from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from langchain_ollama.llms import OllamaLLM
from langchain_core.prompts import ChatPromptTemplate
from vector import retriever

app = FastAPI(title="E-Commerce Review Assistant API")

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model = OllamaLLM(
    model="llama3.2",
    temperature=0.6,  # Lower for more deterministic answers # 0.7
    top_p=0.7,       # Slightly lower than default # 0.9
    repeat_penalty=1.1
)

template = """
You are an expert in answering questions about an e-commerce website and its products.

Here are some relevant customer reviews: {reviews}

Based on these reviews, answer the following question: {question}

Provide a helpful and detailed response considering the customer feedback.
Be professional, concise, and highlight both positive and negative aspects when relevant.
"""
prompt = ChatPromptTemplate.from_template(template)
chain = prompt | model

class QuestionRequest(BaseModel):
    question: str

@app.post("/ask")
async def ask_question(request: QuestionRequest):
    try:
        reviews = retriever.invoke(request.question)
        # Convert Documents to serializable dictionaries
        serializable_reviews = [
            {
                "page_content": doc.page_content,
                "metadata": doc.metadata,
            }
            for doc in reviews
        ]
        result = chain.invoke({"reviews": reviews, "question": request.question})
        return {
            "answer": result,
            "relevant_reviews": serializable_reviews,
            "status": "success"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
@app.get("/health")
async def health_check():
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)