import os
import json
import random
import nltk
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

# Download NLTK data with verification
try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    print("Downloading WordNet...")
    nltk.download('wordnet')
    print("Download completed.")

print("NLTK resources verified.")

class ChatbotModel(nn.Module):
    def __init__(self, input_size, output_size):
        super(ChatbotModel, self).__init__()
        self.fc1 = nn.Linear(input_size, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, output_size)
        self.relu = nn.ReLU()
        self.dropdown = nn.Dropout(0.5)

    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.dropdown(x)
        x = self.relu(self.fc2(x))
        x = self.dropdown(x)
        x = self.fc3(x)
        return x  # Don't forget to return the output!

class ChatbotAssistant:
    def __init__(self, intense_path, function_mappings=None):
        self.model = None
        self.intense_path = intense_path
        self.documents = []
        self.vocabualry = []
        self.intents = []
        self.intents_response = []
        self.function_mappings = function_mappings
        self.X = None  # matrix
        self.y = None  # vector

    @staticmethod
    def tokenize_and_lemmatize(text):
        lemmatizer = nltk.WordNetLemmatizer()
        words = nltk.word_tokenize(text)
        # Fixed: call lower() as a function on each word
        words = [lemmatizer.lemmatize(word.lower()) for word in words]
        return words

# Test the chatbot
chatbot = ChatbotAssistant('intents.json')
print(chatbot.tokenize_and_lemmatize(
    "hello world how are your, i am programming in python today."
))