import os
import json
import random
import re
import nltk
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from nltk.stem import WordNetLemmatizer
import time
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import threading
import streamlit as st
from typing import Optional

# Initialize both FastAPI and Streamlit in the same process
app = FastAPI()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Download NLTK data
nltk.download('punkt')
nltk.download('wordnet')

# Enhanced order database
ORDER_DATABASE = {
    "ORD12345": {
        "status": "shipped",
        "tracking_number": "UPS1Z23456789",
        "items": ["Wireless Headphones", "USB-C Cable"],
        "estimated_delivery": "2023-11-25",
        "customer": "John Doe",
        "order_date": "2023-11-18"
    },
    "ORD67890": {
        "status": "out_for_delivery",
        "tracking_number": "FEDEX987654321",
        "items": ["Smart Watch"],
        "estimated_delivery": "2023-11-22",
        "customer": "Jane Smith",
        "order_date": "2023-11-15"
    },
    "ORD13579": {
        "status": "processing",
        "tracking_number": None,
        "items": ["Gaming Laptop"],
        "estimated_delivery": "2023-12-05",
        "customer": "Mike Johnson",
        "order_date": "2023-11-20"
    },
    "ORD24680": {
        "status": "delivered",
        "tracking_number": "USPS9461203690",
        "items": ["Bluetooth Speaker", "USB-C Adapter"],
        "estimated_delivery": "2023-11-18",
        "customer": "Sarah Williams",
        "order_date": "2023-11-10"
    }
}

# Product database
PRODUCT_DATABASE = {
    "airpods pro": {
        "description": "Active Noise Cancellation for immersive sound. Transparency mode for hearing what's happening around you.",
        "compatibility": "iPhone 8 or later with iOS 14 or later, iPad with iPadOS 14 or later, Apple Watch with watchOS 7 or later, Mac with macOS Big Sur or later",
        "warranty": "1-year limited warranty, 90-day complimentary support",
        "features": ["Active Noise Cancellation", "Adaptive EQ", "Sweat and water resistant", "Up to 4.5 hours of listening time"],
        "price": 249.99
    },
    "wireless headphones": {
        "description": "Premium over-ear headphones with 30-hour battery life and built-in microphone.",
        "compatibility": "Bluetooth-enabled devices including smartphones, tablets, and computers",
        "warranty": "2-year limited warranty",
        "features": ["Bluetooth 5.0", "Noise isolation", "Built-in mic", "Foldable design"],
        "price": 179.99
    },
    "smart watch": {
        "description": "Fitness tracker and smartwatch with heart rate monitoring and GPS.",
        "compatibility": "Android 6.0+ or iOS 12.0+, Bluetooth 4.0+",
        "warranty": "1-year limited warranty",
        "features": ["Heart rate monitor", "Sleep tracking", "Water resistant", "7-day battery life"],
        "price": 199.99
    }
}

# Create intents file if it doesn't exist
INTENTS_FILE = 'intents_ecommerce.json'
if not os.path.exists(INTENTS_FILE):
    intents_data = {
        "intents": [
            {
                "tag": "greeting",
                "patterns": ["Hi", "Hello", "Hey", "Good morning", "Good afternoon"],
                "responses": ["Hello! How can I help you today?", "Hi there! How can I assist you?"],
                "context": []
            },
            {
                "tag": "goodbye",
                "patterns": ["Bye", "Goodbye", "See you later"],
                "responses": ["Goodbye! Come back soon!", "Have a great day!"],
                "context": []
            },
            {
                "tag": "order_status",
                "patterns": ["Where is my order?", "Order status", "Has my order shipped?"],
                "responses": ["I can check your order status. What's your order number?"],
                "context": []
            },
            {
                "tag": "returns",
                "patterns": ["How do I return?", "Return policy", "I want to return"],
                "responses": ["I can help with returns. What's your order number?"],
                "context": []
            },
            {
                "tag": "product_info",
                "patterns": ["Tell me about [product]", "What's [product] like?", "Info about [product]"],
                "responses": ["Here's information about [product]"],
                "context": []
            },
            {
                "tag": "compatibility",
                "patterns": ["Does this work with iPhone?", "Android compatible?", "Will this work on my device?"],
                "responses": ["Let me check the compatibility for you"],
                "context": []
            },
            {
                "tag": "warranty",
                "patterns": ["What's the warranty?", "How long is warranty?", "Warranty period"],
                "responses": ["Let me check the warranty information"],
                "context": []
            }
        ]
    }
    with open(INTENTS_FILE, 'w') as f:
        json.dump(intents_data, f, indent=2)

class ChatbotModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(ChatbotModel, self).__init__()
        self.layer1 = nn.Linear(input_size, hidden_size)
        self.layer2 = nn.Linear(hidden_size, hidden_size)
        self.layer3 = nn.Linear(hidden_size, output_size)
        self.dropout = nn.Dropout(0.5)

    def forward(self, x):
        x = F.relu(self.layer1(x))
        x = self.dropout(x)
        x = F.relu(self.layer2(x))
        x = self.dropout(x)
        x = self.layer3(x)
        return x

class ChatbotDataset(Dataset):
    def __init__(self, X, y):
        self.X = X
        self.y = y

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]

class ECommerceChatbot:
    def __init__(self, intents_file):
        self.lemmatizer = WordNetLemmatizer()
        self.intents = self.load_intents(intents_file)
        self.vocabulary = []
        self.tags = []
        self.xy = []
        self.model = None
        self.context = {
            'data': {},
            'last_updated': time.time(),
            'awaiting_for': None,
            'current_order': None
        }
        self.setup_nlp()
        self.initialize_model()

    def load_intents(self, intents_file):
        with open(intents_file) as file:
            return json.load(file)

    def setup_nlp(self):
        for intent in self.intents['intents']:
            tag = intent['tag']
            self.tags.append(tag)
            for pattern in intent['patterns']:
                words = nltk.word_tokenize(pattern)
                self.vocabulary.extend(words)
                self.xy.append((words, tag))

        self.vocabulary = [self.lemmatizer.lemmatize(word.lower())
                         for word in self.vocabulary if word not in ['?', '!', '.', ',']]
        self.vocabulary = sorted(set(self.vocabulary))
        self.tags = sorted(set(self.tags))

    def initialize_model(self):
        MODEL_FILE = 'ecommerce_model.pth'
        input_size = len(self.vocabulary)
        hidden_size = 128
        output_size = len(self.tags)
        
        self.model = ChatbotModel(input_size, hidden_size, output_size)
        
        if os.path.exists(MODEL_FILE):
            self.model.load_state_dict(torch.load(MODEL_FILE))
        else:
            self.train_model()
            torch.save(self.model.state_dict(), MODEL_FILE)
        
        self.model.eval()

    def train_model(self):
        X_train = []
        y_train = []

        for (pattern_words, tag) in self.xy:
            bag = self.bag_of_words(' '.join(pattern_words))
            X_train.append(bag)
            y_train.append(self.tags.index(tag))

        X_train = np.array(X_train)
        y_train = np.array(y_train)

        input_size = len(X_train[0])
        hidden_size = 128
        output_size = len(self.tags)
        batch_size = 8
        learning_rate = 0.001
        num_epochs = 500

        dataset = ChatbotDataset(torch.from_numpy(X_train), torch.from_numpy(y_train))
        dataloader = DataLoader(dataset=dataset, batch_size=batch_size, shuffle=True)

        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(self.model.parameters(), lr=learning_rate)

        for epoch in range(num_epochs):
            for (words, labels) in dataloader:
                outputs = self.model(words)
                loss = criterion(outputs, labels)
                
                optimizer.zero_grad()
                loss.backward()
                optimizer.step()
            
            if (epoch+1) % 100 == 0:
                print(f'Epoch [{epoch+1}/{num_epochs}]')

        print('Training complete!')

    def bag_of_words(self, sentence):
        sentence_words = [self.lemmatizer.lemmatize(word.lower()) 
                        for word in nltk.word_tokenize(sentence)]
        bag = [0] * len(self.vocabulary)
        for s_word in sentence_words:
            for i, word in enumerate(self.vocabulary):
                if word == s_word:
                    bag[i] = 1
        return np.array(bag, dtype=np.float32)

    def predict_intent(self, sentence):
        sentence = re.sub(r'[^\w\s]', '', sentence.lower()).strip()

        order_match = re.search(r'(?:order|ord|#)?\s*(\d{5,8})', sentence, re.IGNORECASE)
        if order_match:
            order_num = "ORD" + order_match.group(1)
            if order_num in ORDER_DATABASE:
                self.context['current_order'] = order_num
                if self.context.get('awaiting_for') == 'order_status':
                    return 'order_status', 1.0
                elif self.context.get('awaiting_for') == 'returns':
                    return 'returns', 1.0
                else:
                    return 'order_found', 1.0

        X = self.bag_of_words(sentence)
        X = torch.from_numpy(X.reshape(1, X.shape[0]))

        with torch.no_grad():
            output = self.model(X)

        probs = torch.softmax(output, dim=1)
        confidence, predicted = torch.max(probs, dim=1)
        tag = self.tags[predicted.item()]

        if confidence.item() < 0.5:
            return "low_confidence", confidence.item()
            
        return tag, confidence.item()

    def get_response(self, intent_tag):
        for intent in self.intents['intents']:
            if intent['tag'] == intent_tag:
                response = random.choice(intent['responses'])
                if '[order_number]' in response and self.context.get('current_order'):
                    response = response.replace('[order_number]', self.context['current_order'])
                return response
        return "I'm not sure how to respond to that."

    def get_order_status(self, order_number):
        order = ORDER_DATABASE.get(order_number.upper())
        if not order:
            return f"Sorry, I couldn't find order {order_number}. Please check the number."

        response = [
            f"📦 Order {order_number}",
            f"🛒 Items: {', '.join(order['items'])}",
            f"📅 Ordered on: {order.get('order_date', 'Unknown')}",
            f"🔄 Status: {order['status'].replace('_', ' ').title()}"
        ]

        if order['tracking_number']:
            carrier = "UPS" if order['tracking_number'].startswith("UPS") else "FedEx"
            tracking_link = {
                "UPS": f"https://www.ups.com/track?tracknum={order['tracking_number']}",
                "FedEx": f"https://www.fedex.com/fedextrack/?trknbr={order['tracking_number']}",
                "USPS": f"https://tools.usps.com/go/TrackConfirmAction?tLabels={order['tracking_number']}"
            }.get(carrier, f"https://tracking.example.com/?num={order['tracking_number']}")

            response.extend([
                f"📮 Tracking #: {order['tracking_number']}",
                f"🔗 Track here: {tracking_link}"
            ])

        if order['estimated_delivery']:
            status = "✅ Delivered on" if order['status'] == 'delivered' else "⏳ Estimated delivery"
            response.append(f"{status}: {order['estimated_delivery']}")

        return '\n'.join(response)

    def get_return_info(self, order_number):
        order = ORDER_DATABASE.get(order_number.upper())
        if not order:
            return f"Sorry, order {order_number} wasn't found in our system."

        if order['status'] == 'processing':
            return "Your order hasn't shipped yet. Would you like to cancel instead?"

        return '\n'.join([
            f"🔄 Return options for order {order_number}:",
            f"📦 Items: {', '.join(order['items'])}",
            "1. 📱 Initiate return online: https://returns.example.com/start",
            "2. 📍 Visit a drop-off location: https://returns.example.com/locations",
            "3. 📞 Contact support for help: 1-800-RETURNS",
            "📅 Note: Items must be returned within 30 days of delivery."
        ])

    def get_product_info(self, product_name):
        product_name = product_name.lower()
        best_match = None
        best_score = 0

        for key in PRODUCT_DATABASE:
            score = len(set(product_name.split()) & set(key.split()))
            if score > best_score:
                best_score = score
                best_match = key

        if not best_match or best_score < 1:
            return "I couldn't find information about that product. Could you be more specific?"

        product = PRODUCT_DATABASE[best_match]
        response = [
            f"📌 {best_match.title()} (${product.get('price', 'N/A')}):",
            f"📝 Description: {product['description']}",
            f"🔌 Compatibility: {product['compatibility']}",
            f"🛡️ Warranty: {product['warranty']}",
            "✨ Features:",
            *[f"- {feature}" for feature in product['features']],
            f"\n💳 Order here: https://shop.example.com/{best_match.replace(' ', '-')}"
        ]

        return '\n'.join(response)

    def process_message(self, message):
        if not message.strip():
            return "Please type your message."

        if time.time() - self.context.get('last_updated', 0) > 300:
            self.context = {
                'data': {},
                'last_updated': time.time(),
                'awaiting_for': None,
                'current_order': None
            }

        self.context['last_updated'] = time.time()

        intent_tag, confidence = self.predict_intent(message)

        if intent_tag == "low_confidence":
            return "I'm not sure I understand. Could you rephrase or provide more details?"
        elif intent_tag == "error":
            return "I encountered an error processing your request. Please try again."

        if intent_tag in ['order_status', 'returns']:
            if not self.context.get('current_order'):
                self.context['awaiting_for'] = intent_tag
                return "Please provide your order number (e.g., ORD12345 or just 12345):"

            if intent_tag == 'order_status':
                return self.get_order_status(self.context['current_order'])
            else:
                return self.get_return_info(self.context['current_order'])

        if intent_tag == 'order_found':
            return f"Found order {self.context['current_order']}. How can I help you with it?"

        if intent_tag == 'product_info':
            product_query = re.sub(r'(tell me about|info|information|details)', '', message, flags=re.IGNORECASE)
            return self.get_product_info(product_query.strip())

        if intent_tag == 'compatibility':
            if 'iphone' in message.lower():
                return "✅ Works with iPhone 8 through iPhone 15 series\n🔄 Requires iOS 12 or later"
            elif 'android' in message.lower():
                return "✅ Works with Android 6.0 and above"
            else:
                return "Most products work with both iOS and Android. Which product are you asking about?"

        if intent_tag == 'warranty':
            return "🛡️ Standard warranty is 1 year for most products. Some items have extended warranties available."

        return self.get_response(intent_tag)

# Initialize chatbot
chatbot = ECommerceChatbot(INTENTS_FILE)

# FastAPI endpoints
class Message(BaseModel):
    text: str
    session_id: Optional[str] = None

@app.post("/chat")
async def chat(message: Message):
    try:
        response = chatbot.process_message(message.text)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/")
async def root():
    return {"message": "E-Commerce Chatbot API is running"}

def run_fastapi():
    uvicorn.run(app, host="0.0.0.0", port=8000)

def run_streamlit():
    st.set_page_config(page_title="E-Commerce Chatbot", page_icon=":robot_face:")
    
    # Initialize session state for chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []
    
    st.title("E-Commerce Chatbot")
    st.write("Ask me about your orders, products, or anything else!")
    
    # Display chat messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
    
    # Chat input
    if prompt := st.chat_input("Type your message here..."):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Display user message
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # Get bot response (using the chatbot directly instead of API call)
        try:
            bot_response = chatbot.process_message(prompt)
        except Exception as e:
            bot_response = f"Sorry, I encountered an error: {str(e)}"
        
        # Display bot response
        with st.chat_message("assistant"):
            st.markdown(bot_response)
        
        # Add bot response to chat history
        st.session_state.messages.append({"role": "assistant", "content": bot_response})

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "api":
        run_fastapi()
    else:
        # Run both FastAPI and Streamlit in the same process
        from multiprocessing import Process
        
        api_process = Process(target=run_fastapi)
        api_process.start()
        
        # Give FastAPI a moment to start
        time.sleep(2)
        
        # Run Streamlit in the main process
        run_streamlit()
        
        # Cleanup
        api_process.terminate()