from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json
import torch
import nltk
from nltk.stem import WordNetLemmatizer
import re
import time
import os
import random
from typing import Dict, Any, Tuple

# Initialize NLTK
nltk.download('punkt')
nltk.download('wordnet')

app = FastAPI()

# Allow CORS for Streamlit frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatRequest(BaseModel):
    message: str

class ChatbotModel(torch.nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(ChatbotModel, self).__init__()
        self.layer1 = torch.nn.Linear(input_size, hidden_size)
        self.layer2 = torch.nn.Linear(hidden_size, hidden_size)
        self.layer3 = torch.nn.Linear(hidden_size, output_size)
        self.dropout = torch.nn.Dropout(0.5)

    def forward(self, x):
        x = torch.nn.functional.relu(self.layer1(x))
        x = self.dropout(x)
        x = torch.nn.functional.relu(self.layer2(x))
        x = self.dropout(x)
        x = self.layer3(x)
        return x

class ECommerceChatbot:
    def __init__(self, intents_file: str, model_files: Dict[str, str]):
        self.lemmatizer = WordNetLemmatizer()
        self.intents = self.load_intents(intents_file)
        self.vocabulary = []
        self.tags = []
        self.xy = []
        self.models = {}  # Dictionary to hold multiple models
        self.context = {
            'data': {},
            'last_updated': time.time(),
            'awaiting_for': None,
            'current_order': None
        }
        self.setup_nlp()
        self.load_models(model_files)
        
    def load_intents(self, intents_file: str) -> Dict[str, Any]:
        with open(intents_file) as file:
            return json.load(file)
    
    def setup_nlp(self):
        for intent in self.intents['intents']:
            tag = intent['tag']
            self.tags.append(tag)
            for pattern in intent['patterns']:
                words = nltk.word_tokenize(pattern)
                self.vocabulary.extend(words)
                self.xy.append((words, tag))
        
        self.vocabulary = [self.lemmatizer.lemmatize(word.lower())
                         for word in self.vocabulary if word not in ['?', '!', '.', ',']]
        self.vocabulary = sorted(set(self.vocabulary))
        self.tags = sorted(set(self.tags))
    
    def load_models(self, model_files: Dict[str, str]):
        """Load multiple models from given paths"""
        input_size = len(self.vocabulary)
        output_size = len(self.tags)
        
        for model_name, model_path in model_files.items():
            if os.path.exists(model_path):
                model = ChatbotModel(input_size, 128, output_size)
                model.load_state_dict(torch.load(model_path))
                model.eval()
                self.models[model_name] = model
    
    def bag_of_words(self, sentence: str) -> torch.Tensor:
        sentence_words = [self.lemmatizer.lemmatize(word.lower())
                        for word in nltk.word_tokenize(sentence)]
        bag = [0] * len(self.vocabulary)
        for s_word in sentence_words:
            for i, word in enumerate(self.vocabulary):
                if word == s_word:
                    bag[i] = 1
        return torch.tensor(bag, dtype=torch.float32)
    
    def predict_intent(self, sentence: str) -> Tuple[str, float]:
        """Predict intent using ensemble of models"""
        sentence = re.sub(r'[^\w\s]', '', sentence.lower()).strip()
        
        # Check for order number first
        order_match = re.search(r'(?:order|ord|#)?\s*(\d{5,8})', sentence, re.IGNORECASE)
        if order_match:
            order_num = "ORD" + order_match.group(1)
            if order_num in ORDER_DATABASE:
                self.context['current_order'] = order_num
                if self.context.get('awaiting_for') == 'order_status':
                    return 'order_status', 1.0
                elif self.context.get('awaiting_for') == 'returns':
                    return 'returns', 1.0
                else:
                    return 'order_found', 1.0
        
        # Get predictions from all models
        predictions = []
        X = self.bag_of_words(sentence).unsqueeze(0)
        
        for model_name, model in self.models.items():
            with torch.no_grad():
                output = model(X)
                probs = torch.softmax(output, dim=1)
                confidence, predicted = torch.max(probs, dim=1)
                tag = self.tags[predicted.item()]
                predictions.append((tag, confidence.item()))
        
        # Ensemble method: choose prediction with highest confidence
        best_prediction = max(predictions, key=lambda x: x[1])
        
        if best_prediction[1] < 0.5:
            return "low_confidence", best_prediction[1]
        
        return best_prediction
    
    def get_response(self, intent_tag: str) -> str:
        for intent in self.intents['intents']:
            if intent['tag'] == intent_tag:
                response = random.choice(intent['responses'])
                if '[order_number]' in response and self.context.get('current_order'):
                    response = response.replace('[order_number]', self.context['current_order'])
                return response
        return "I'm not sure how to respond to that."
    
    def get_order_status(self, order_number: str) -> str:
        order = ORDER_DATABASE.get(order_number.upper())
        if not order:
            return f"Sorry, I couldn't find order {order_number}."
        
        response = [
            f"📦 Order {order_number}",
            f"🛒 Items: {', '.join(order['items'])}",
            f"🔄 Status: {order['status'].replace('_', ' ').title()}"
        ]
        
        if order.get('estimated_delivery'):
            response.append(f"⏳ Estimated delivery: {order['estimated_delivery']}")
        
        return '\n'.join(response)
    
    def process_message(self, message: str) -> str:
        if not message.strip():
            return "Please type your message."
        
        # Reset context if inactive for 5 minutes
        if time.time() - self.context.get('last_updated', 0) > 300:
            self.context = {
                'data': {},
                'last_updated': time.time(),
                'awaiting_for': None,
                'current_order': None
            }
        
        self.context['last_updated'] = time.time()
        
        intent_tag, confidence = self.predict_intent(message)
        
        if intent_tag == "low_confidence":
            return "I'm not sure I understand. Could you rephrase?"
        elif intent_tag == "error":
            return "I encountered an error processing your request."
        
        # Handle specific intents
        if intent_tag == 'order_status':
            if not self.context.get('current_order'):
                self.context['awaiting_for'] = 'order_status'
                return "Please provide your order number (e.g., ORD12345 or just 12345):"
            return self.get_order_status(self.context['current_order'])
        
        if intent_tag == 'order_found':
            return f"Found order {self.context['current_order']}. How can I help you with it?"
        
        return self.get_response(intent_tag)

# Sample databases (replace with your actual data)
ORDER_DATABASE = {
    "ORD12345": {
        "status": "shipped",
        "items": ["Wireless Headphones", "USB-C Cable"],
        "estimated_delivery": "2023-11-25"
    },
    "ORD67890": {
        "status": "delivered",
        "items": ["Smart Watch"],
        "estimated_delivery": "2023-11-22"
    }
}

PRODUCT_DATABASE = {
    "airpods pro": {
        "description": "Active Noise Cancellation for immersive sound.",
        "price": 249.99,
        "features": ["Noise Cancellation", "Adaptive EQ"]
    }
}

# Initialize chatbot with multiple models
chatbot = ECommerceChatbot(
    intents_file="intents_ecommerce.json",
    model_files={
        "primary": "ecommerce_model.pth",
        "secondary": "best_model.pth"  # Your other model
    }
)

@app.post("/chat")
async def chat_endpoint(request: ChatRequest):
    try:
        response = chatbot.process_message(request.message)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)