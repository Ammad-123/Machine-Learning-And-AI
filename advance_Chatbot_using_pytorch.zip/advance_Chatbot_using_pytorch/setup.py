import json
import nltk
from nltk.stem import WordNetLemmatizer

nltk.download('punkt')
nltk.download('wordnet')

def process_intents(intents_file):
    with open(intents_file) as f:
        data = json.load(f)
    
    lemmatizer = WordNetLemmatizer()
    vocabulary = []
    tags = []
    xy = []
    
    for intent in data['intents']:
        tag = intent['tag']
        tags.append(tag)
        for pattern in intent['patterns']:
            words = nltk.word_tokenize(pattern)
            vocabulary.extend(words)
            xy.append((words, tag))
    
    vocabulary = [lemmatizer.lemmatize(word.lower()) 
                 for word in vocabulary if word not in ['?', '!', '.', ',']]
    vocabulary = sorted(set(vocabulary))
    tags = sorted(set(tags))
    
    # Save the processed data
    with open('vocabulary.json', 'w') as f:
        json.dump(vocabulary, f)
    
    with open('tags.json', 'w') as f:
        json.dump(tags, f)
    
    print(f"Processed {len(vocabulary)} words and {len(tags)} tags")

if __name__ == "__main__":
    process_intents('intents_ecommerce.json')