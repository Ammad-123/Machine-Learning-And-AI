How to run this project

open two terminal one for frontend and one for backend

run the command  for frontend streamlit run frontend.py
run the command for backend py backend.py