import streamlit as st
import requests
import time
from datetime import datetime

# Configuration
BACKEND_URL = "http://localhost:8000"  # Update if your backend is hosted elsewhere

# Custom CSS for better UI
st.markdown("""
<style>
    .stChatMessage {
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 12px;
    }
    .user-message {
        background-color: #f0f2f6;
        margin-left: 20%;
    }
    .assistant-message {
        background-color: #e3f2fd;
        margin-right: 20%;
    }
    .review-card {
        padding: 12px;
        margin: 8px 0;
        border-left: 4px solid #4e79a7;
        background-color: #f8f9fa;
        border-radius: 4px;
    }
    .rating-5 { color: #28a745; }
    .rating-4 { color: #5cb85c; }
    .rating-3 { color: #ffc107; }
    .rating-2 { color: #fd7e14; }
    .rating-1 { color: #dc3545; }
    .loading-dots {
        display: inline-flex;
        align-items: center;
    }
    .loading-dots span {
        animation: blink 1.4s infinite both;
        margin: 0 2px;
    }
    .loading-dots span:nth-child(2) {
        animation-delay: 0.2s;
    }
    .loading-dots span:nth-child(3) {
        animation-delay: 0.4s;
    }
    @keyframes blink {
        0% { opacity: 0.2; }
        20% { opacity: 1; }
        100% { opacity: 0.2; }
    }
    .status-message {
        font-style: italic;
        color: #666;
        font-size: 0.9em;
        margin-top: 8px;
    }
</style>
""", unsafe_allow_html=True)

def display_review(review):
    rating = review["metadata"]['rating']  # Access as dictionary key
    date = review["metadata"]['date']
    st.markdown(f"""
    <div class="review-card">
        <div><strong>Rating:</strong> <span class="rating-{rating}">{"★" * rating + "☆" * (5-rating)}</span></div>
        <div><strong>Date:</strong> {date}</div>
        <div>{review["page_content"]}</div>
    </div>
    """, unsafe_allow_html=True)

def show_loading_message():
    """Show animated loading dots with status message"""
    return st.markdown("""
    <div class="loading-dots">
        <span>●</span>
        <span>●</span>
        <span>●</span>
    </div>
    <div class="status-message">Analyzing reviews and generating response...</div>
    """, unsafe_allow_html=True)

def chat_with_assistant():
    st.title("📦 E-Commerce Review Assistant")
    st.markdown("Ask questions about products based on customer reviews")

    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat messages
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("reviews"):
                with st.expander("📌 Relevant Reviews"):
                    for review in message["reviews"]:
                        display_review(review)
            # if message.get("processing_time"):
            #     st.caption(f"Generated in {message['processing_time']:.2f} seconds")

    # Accept user input
    if prompt := st.chat_input("Ask about products or customer experiences..."):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        # Display user message
        with st.chat_message("user"):
            st.markdown(prompt)
        
        # Display assistant placeholder
        with st.chat_message("assistant"):
            message_placeholder = st.empty()
            status_placeholder = st.empty()
            
            # Show loading indicator
            status_placeholder.markdown("""
            <div class="loading-dots">
                <span>●</span>
                <span>●</span>
                <span>●</span>
            </div>
            <div class="status-message">Searching through customer reviews...</div>
            """, unsafe_allow_html=True)
            
            full_response = ""
            start_time = time.time()
            
            try:
                # Call backend API
                response = requests.post(
                    f"{BACKEND_URL}/ask",
                    json={"question": prompt}
                )
                
                if response.status_code == 200:
                    response_data = response.json()
                    
                    if response_data["status"] == "success":
                        # Update status message
                        status_placeholder.markdown("""
                        <div class="loading-dots">
                            <span>●</span>
                            <span>●</span>
                            <span>●</span>
                        </div>
                        <div class="status-message">Generating response...</div>
                        """, unsafe_allow_html=True)
                        
                        # Stream the response
                        answer = response_data["answer"]
                        words = answer.split()
                        
                        for i, word in enumerate(words):
                            full_response += word + " "
                            progress = (i + 1) / len(words)
                            
                            # Update message with typing indicator
                            message_placeholder.markdown(full_response + "▌")
                            
                            # Vary speed based on word length (shorter delay for short words)
                            delay = 0.05 if len(word) < 8 else 0.08
                            time.sleep(delay)
                        
                        # Final message without cursor
                        message_placeholder.markdown(full_response)
                        status_placeholder.empty()
                        
                        processing_time = time.time() - start_time
                        
                        # Add assistant response to chat history
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": full_response,
                            "reviews": response_data["relevant_reviews"],
                            "processing_time": processing_time
                        })
                        
                        # Show reviews in expander
                        with st.expander("📌 Relevant Reviews"):
                            for review in response_data["relevant_reviews"]:
                                display_review(review)
                    else:
                        status_placeholder.empty()
                        st.error("Failed to get response from assistant")
                else:
                    status_placeholder.empty()
                    st.error(f"API Error: {response.status_code}")
            except Exception as e:
                status_placeholder.empty()
                st.error(f"Error: {str(e)}")

if __name__ == "__main__":
    chat_with_assistant()