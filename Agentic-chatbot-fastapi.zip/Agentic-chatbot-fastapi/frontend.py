import streamlit as st
import requests

# 🎨 Set up the page with a visually appealing layout
st.set_page_config(page_title="LangGraph AI Agent", layout="centered")

# 🌟 Apply custom styles
st.markdown("""
    <style>
        body { background-color: #f5f5f5; }
        .stTextArea textarea { background-color: #eef2ff; border-radius: 10px; }
        .stButton button { background-color: #4CAF50; color: white; font-size: 18px; border-radius: 10px; }
        .stRadio div { background-color: #fff5e1; border-radius: 8px; padding: 5px; }
        .stSelectbox div { background-color: #e0f7fa; border-radius: 8px; }
        .stCheckbox div { background-color: #fce4ec; border-radius: 8px; }
    </style>
""", unsafe_allow_html=True)

# 🏆 App Title with better visibility
st.markdown("<h1 style='text-align: center; color: #4CAF50;'>🤖 AI Chatbot Agents</h1>", unsafe_allow_html=True)
st.markdown("<h3 style='text-align: center; color: #555;'>Create and Interact with AI Agents</h3>", unsafe_allow_html=True)

# ✍️ Define AI Behavior
st.subheader("🛠️ Define Your AI Agent:")
system_prompt = st.text_area("System Prompt:", height=70, placeholder="E.g., Act as a financial advisor...")

# 🔍 Select Model Provider
st.subheader("🌍 Select AI Model Provider:")
provider = st.radio("", ("Groq", "OpenAI"))

# 🔬 Select Model Based on Provider
MODEL_NAMES_GROQ = ["llama-3.3-70b-versatile", "mixtral-8x7b-32768"]
MODEL_NAMES_OPENAI = ["gpt-4o-mini"]

if provider == "Groq":
    selected_model = st.selectbox("Choose Groq Model:", MODEL_NAMES_GROQ)
else:
    selected_model = st.selectbox("Choose OpenAI Model:", MODEL_NAMES_OPENAI)

# 🌐 Enable Web Search Option
allow_web_search = st.checkbox("🔎 Enable Web Search")

# 💬 User Query
st.subheader("💡 Ask Your AI Agent:")
user_query = st.text_area("Your Question:", height=150, placeholder="E.g., What are the best stocks to invest in 2025?")

# 🌍 Backend API URL
API_URL = "http://127.0.0.1:9000/chat"

# 🚀 Submit Button
if st.button("🚀 Ask Agent!"):
    if user_query.strip():
        # 📡 Connect with FastAPI Backend
        payload = {
            "model_name": selected_model,
            "model_provider": provider,
            "system_prompt": system_prompt,
            "messages": [user_query],
            "allow_search": allow_web_search
        }

        response = requests.post(API_URL, json=payload)

        if response.status_code == 200:
            response_data = response.json()
            if "error" in response_data:
                st.error(response_data["error"])
            else:
                st.subheader("💬 AI Response:")
                st.success(response_data)
        else:
            st.error("❌ Failed to fetch response from the server.")

